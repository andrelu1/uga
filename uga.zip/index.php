<?php

echo "Olá eu sou uma pagina de PHP, vc quer ser meu amigo?";

?>
